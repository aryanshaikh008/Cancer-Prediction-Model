from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

# Load the trained model and scaler
with open('model.pkl', 'rb') as model_file:
    model = pickle.load(model_file)

with open('scaler.pkl', 'rb') as scaler_file:
    scaler = pickle.load(scaler_file)

# Define the home route
@app.route('/')
def home():
    return render_template('index.html', prediction_text="")

# Define the predict route
@app.route('/predict', methods=['POST'])
def predict():
    # Get input features from the form
    features = [float(request.form.get(f'feature_{i}')) for i in range(1, 31)]

    # Convert the features to a NumPy array
    input_features = np.array([features])

    # Standardize input features
    input_features_scaled = scaler.transform(input_features)

    # Make a prediction using the loaded model
    prediction = model.predict(input_features_scaled)

    return render_template('index.html', prediction_text=f'Prediction: {prediction[0]}')

if __name__ == '__main__':
    app.run(debug=True)
